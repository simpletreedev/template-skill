#!/bin/bash
# Template Generator Helper Functions
# Usage: source scripts/template-helpers.sh

# Get script directory (works when sourced from anywhere)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MANAGER_SCRIPT="${SCRIPT_DIR}/template-manager.py"

# State
get_state_val() { python3 "${MANAGER_SCRIPT}" get "$1"; }
get_slug() { get_state_val "slug"; }
get_name() { get_state_val "name"; }
get_description() { get_state_val "description"; }
get_progress_json() { python3 "${MANAGER_SCRIPT}" progress; }
update_state() { python3 "${MANAGER_SCRIPT}" update "$@"; }
skip_state() { python3 "${MANAGER_SCRIPT}" skip "$@"; }

# Combined: Get count and update state in one call
update_step_state() {
  local step_number=$1
  local item_type=$2
  local index_file=$3

  local count=$(get_count "${SLUG}" "${index_file}" "${item_type}")
  update_state ${step_number} "${item_type}" ${count}
}

# Index
add_to_index() { python3 "${MANAGER_SCRIPT}" add_to_index "$@"; }
add_agent_to_index() { python3 "${MANAGER_SCRIPT}" add_to_index "$1" "$2" "$3" "$4" "$5" "$6"; }
get_count() { python3 "${MANAGER_SCRIPT}" get_count "$@"; }

# Utils
ensure_dir() { python3 "${MANAGER_SCRIPT}" ensure_dir "$@"; }
upload_to_cloud() { python3 "${MANAGER_SCRIPT}" upload "$@"; }

# Check ClaudeWS servers (auto-loads .env from script directory)
check_claudews_servers() {
  local env_file="${SCRIPT_DIR}/../.env"
  local api_url=""

  if [[ -f "${env_file}" ]]; then
    # Extract PRIVOS_API_URL from .env file using grep
    api_url=$(grep "^PRIVOS_API_URL=" "${env_file}" 2>/dev/null | cut -d'=' -f2-)
    # Remove quotes and whitespace
    api_url=$(echo "$api_url" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//' | tr -d '"\047')
  fi

  python3 "${MANAGER_SCRIPT}" check_claudews "${api_url}"
}

# Init
init_step() {
  [[ -f ".env" ]] && { set -a; source .env; set +a; }
  eval $(python3 "${MANAGER_SCRIPT}" export_vars)
}
