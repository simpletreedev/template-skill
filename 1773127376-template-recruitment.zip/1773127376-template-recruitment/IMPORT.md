# Corporate Recruitment - Import Instructions

## Overview

Template for corporate hiring with candidate tracking and interview coordination. Perfect for low-volume hiring (1-5 positions/month) with focus on candidate organization and interview scheduling.

## What's Included

- 1 Lists, 0 Documents, 3 Files
- 0 Automations, 1 Chat Agents, 1 AI Workspaces

## Import Steps

1. Go to PrivOs app
2. Navigate to Templates
3. Click "Import Template"
4. Upload this ZIP file
5. Your template is ready to use!

## Getting Started

After importing, you'll find:
- **Candidates Pipeline** list ready to track applicants through 8 hiring stages
- **Interview Feedback Form** (Word) - Standardized evaluation template
- **Candidate Tracking Spreadsheet** (Excel) - Quick overview of all candidates
- **Hiring Process Guide** (PDF) - Reference document for your hiring workflow
- **Email Drafting Assistant** - AI workflow for drafting interview invitations
- **AI Workspace** (local server) - Recruitment skills, commands, and agents:
  - Skills: Resume screening, candidate evaluation, interview questions, email drafting
  - Commands: /screen, /evaluate, /interview-questions, /email
  - Agents: Recruiting Coordinator, Candidate Screener

## Using Your Template

1. **Add Candidates** to the Candidates Pipeline list with their information
2. **Move Candidates** through stages as they progress (New Application → Hired)
3. **Use File Templates** for interview feedback and candidate tracking
4. **Draft Emails** with the Email Drafting Assistant workflow
5. **Screen Candidates** using AI skills and commands from your local workspace

Enjoy your new template! 🚀
