# /screen - Resume Screening Command

## Description
Quickly screen a candidate's resume against job requirements.

## Usage
```
/screen [job_requirements] [candidate_resume]
```

## Examples
```
/screen "Need 5+ years Python, AWS experience" "John Doe, 6 years Python, AWS certified"
```

## Output
- Qualification match summary
- Overall fit score
- Proceed/reject recommendation
