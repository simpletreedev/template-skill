# /email - Draft Recruitment Email

## Description
Draft professional recruitment emails for any hiring stage.

## Usage
```
/email [type] [candidate_name] [role] [details]
```

## Types
- invitation - Interview invitation
- rejection - Rejection notice
- offer - Job offer
- follow-up - Follow-up communication

## Examples
```
/email invitation "John Doe" "Software Engineer" "Monday 2pm, Zoom link provided"
```

## Output
Complete email with subject line and professional formatting.
