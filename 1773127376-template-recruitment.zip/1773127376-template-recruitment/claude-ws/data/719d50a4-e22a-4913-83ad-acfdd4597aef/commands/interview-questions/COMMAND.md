# /interview-questions - Generate Interview Questions

## Description
Generate role-specific interview questions with evaluation criteria.

## Usage
```
/interview-questions [role] [experience_level] [focus_areas]
```

## Examples
```
/interview-questions "Software Engineer" "Senior" "technical, leadership"
```

## Output
- Technical questions
- Behavioral questions
- Cultural fit questions
- Evaluation rubric
