# /evaluate - Candidate Evaluation Command

## Description
Evaluate a candidate's overall fit for the role.

## Usage
```
/evaluate [candidate_info] [interview_notes]
```

## Examples
```
/evaluate "Sarah Johnson, Senior Marketing Manager" "Strong digital skills, great culture fit, 7 years experience"
```

## Output
- Multi-dimensional assessment
- Hire/no hire recommendation
- Key strengths and concerns
