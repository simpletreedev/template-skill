# Interview Question Generator Skill

## Overview
This skill generates role-specific interview questions tailored to job requirements and experience levels.

## When to Use
- When preparing for an interview
- When creating interview guides
- When updating question banks for specific roles

## How to Use
1. Provide the job role and description
2. Specify experience level (entry, mid, senior)
3. Mention focus areas (technical, behavioral, cultural)
4. The AI will generate:
   - Technical questions (role-specific)
   - Behavioral questions (STAR method)
   - Cultural fit questions
   - Evaluation criteria for each question

## Question Types
- Technical Skills - Assess job-specific knowledge
- Problem Solving - Evaluate analytical thinking
- Behavioral - Past behavior predicts future behavior
- Cultural Fit - Alignment with company values
- Situational - How they'd handle scenarios

## Example Input
```
Role: Senior Marketing Manager
Experience: Senior level (7+ years)
Focus: Digital marketing, team leadership, data-driven decisions
```

## Output Format
Organized question list with evaluation rubrics and scoring guides.
