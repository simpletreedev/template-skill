# Resume Screening Skill

## Overview
This skill screens candidate resumes against job requirements to identify qualified applicants.

## When to Use
- When you receive a new candidate application
- When reviewing resumes for a specific job opening
- When you need to quickly assess if a candidate meets minimum qualifications

## How to Use
1. Provide the job requirements (skills, experience, education)
2. Provide the candidate's resume or key qualifications
3. The AI will evaluate fit and provide:
   - Qualification summary (met/not met for each requirement)
   - Overall fit score (1-10)
   - Recommendation (proceed/reject)
   - Key strengths and concerns

## Example Input
```
Job Requirements:
- 5+ years software engineering experience
- Python and JavaScript proficiency
- Bachelor's in CS or related field
- Experience with cloud platforms (AWS/GCP)

Candidate Resume:
- Michael Chen, 4 years experience
- Skills: Python, React, Node.js
- BS Computer Science
- No cloud experience listed
```

## Output Format
The AI provides a structured evaluation with scoring and recommendation.
