# Candidate Evaluation Skill

## Overview
This skill provides comprehensive candidate evaluation across multiple dimensions including technical skills, cultural fit, and experience.

## When to Use
- After interviewing a candidate
- When comparing multiple candidates
- When making hiring decisions

## How to Use
1. Provide candidate information (resume, interview notes, assessment scores)
2. Specify evaluation criteria if needed
3. The AI will provide:
   - Technical skills assessment
   - Cultural fit evaluation
   - Experience relevance
   - Overall recommendation (Hire/No Hire/Consider)
   - Key strengths and concerns

## Evaluation Dimensions
- Technical Competence (skills, knowledge, problem-solving)
- Cultural Fit (values, communication, teamwork)
- Experience (relevant background, achievements)
- Growth Potential (learning ability, career progression)
- References (if available)

## Output Format
Structured evaluation with scores for each dimension and overall hiring recommendation.
