# Recruitment Email Assistant Skill

## Overview
This skill drafts professional recruitment emails for various stages of the hiring process.

## When to Use
- Scheduling interviews
- Sending rejection notices
- Extending job offers
- Follow-up communications
- Status updates

## How to Use
1. Specify email type (invitation, rejection, offer, follow-up)
2. Provide candidate details (name, role, stage in process)
3. Include relevant information (dates, times, next steps)
4. The AI will draft a professional email with:
   - Appropriate tone and structure
   - All necessary details
   - Clear call-to-action
   - Professional closing

## Email Types
- Interview Invitation - Scheduling details, what to expect
- Rejection Notice - Professional, respectful closure
- Offer Letter - Congratulations, terms, next steps
- Follow-up - Requesting references, additional information
- Status Update - Keeping candidates informed

## Tone Guidelines
- Professional and formal (corporate)
- Respectful and timely
- Clear and concise
- Maintain positive candidate experience

## Output Format
Complete email with subject line, body, and professional closing.
